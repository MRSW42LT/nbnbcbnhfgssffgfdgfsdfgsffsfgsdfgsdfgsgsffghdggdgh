<?php
include 'inc/head.html';

?>

<h1>ADICIONAR CONTATOS</h1>
<form action="adicionarContatoSubmit.php" method="POST">
	<label>Nome:</label><br><br>
	<input type="text" name="nome" required="required"><br><br>
	<label>DDD:</label><br><br>
	<input type="text" name="ddd" required="required"><br><br>
	<label>Celular:</label><br><br>
	<input type="text" name="celular" required="required"><br><br>
	<label>Email:</label><br><br>
	<input type="email" name="email" required="required"><br><br>
	<label>Cidade:</label><br><br>
	<input type="text" name="cidade" required="required"><br><br>
	<label>Endereço:</label><br><br>
	<input type="text" name="endereco" required="required"><br><br>
	<label>Profissão:</label><br><br>
	<input type="text" name="profissao" required="required"><br><br>
	<label>Formação:</label><br><br>
	<input type="text" name="formacao" required="required"><br><br>
	<label>Facebook:</label><br><br>
	<input type="text" name="facebook" required="required"><br><br>
	<label>Instagram:</label><br><br>
	<input type="text" name="instagram" required="required"><br><br>
	<label>Data Nascimento:</label><br><br>
	<input type="date" name="data_nasc" required="required"><br><br>
	<label>Foto:</label><br><br>
	<input type="text" name="url_foto" required="required"><br><br>

	<input type="submit" name="btCadastrar" value="Cadastrar">
</form>