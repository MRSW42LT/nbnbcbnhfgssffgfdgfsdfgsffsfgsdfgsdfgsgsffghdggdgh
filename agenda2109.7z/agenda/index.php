<?php
include 'classes/contatos.class.php';
include 'inc/head.html';
$contato = new Contatos();

?>
<div class="w-75 mx-auto">
	<a href="adicionarContato.php">Adicionar</a>
	<br><br>
	<table border="2" width="100%">
		<tr>
			<th>ID</th>
			<th>NOME</th>
			<th>DDD</th>
			<th>CELULAR</th>
			<th>EMAIL</th>
			<th>CIDADE</th>
			<th>ENDEREÇO</th>
			<th>PROFISSÃO</th>
			<th>FORMAÇÃO</th>
			<th>FACEBOOK</th>
			<th>INSTAGRAM</th>
			<th>DATA NASCIMENTO</th>
			<th>FOTO</th>
			<th>AÇÕES</th>
		</tr>
		<?php
			$lista = $contato->listar();
			foreach($lista as $item):
		?>
		<tr>
			<td><?php echo $item['id']; ?></td>
			<td><?php echo $item['nome']; ?></td>
			<td><?php echo $item['ddd']; ?></td>
			<td><?php echo $item['celular']; ?></td>
			<td><?php echo $item['email']; ?></td>
			<td><?php echo $item['cidade']; ?></td>
			<td><?php echo $item['endereco']; ?></td>
			<td><?php echo $item['profissao']; ?></td>
			<td><?php echo $item['formacao']; ?></td>
			<td><?php echo $item['facebook']; ?></td>
			<td><?php echo $item['instagram']; ?></td>
			<td><?php echo implode("/", array_reverse(explode("-", $item ['data_nasc'])));?></td>
			<td><?php echo $item['url_foto']; ?></td>
			<td> 
				<a href="#">EDITAR</a>
				<a href="excluir_contatos.php?id=<?php echo $item['id'];?>">> EXCLUIR</a>
			</td>
		</tr>
		<?php
			endforeach;
		?>
	</table>
</div>


