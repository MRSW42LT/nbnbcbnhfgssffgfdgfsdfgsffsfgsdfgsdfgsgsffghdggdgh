<?php
include "classes/contatos.class.php";
$contato = new Contatos();

if(!empty($_GET['id'])){
    $id = $_GET['id'];
    $contato->excluir($id);
    header("location: index.php");
}
else{
    echo '<script type="text/javascript">alert("Erro ao excluir")</script>';
    header("location: index.php");
}