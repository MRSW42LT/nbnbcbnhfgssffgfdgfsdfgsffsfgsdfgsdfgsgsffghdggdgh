<?php
include 'classes/conexao.class.php';

$con = new Conexao();

$con->conectar();