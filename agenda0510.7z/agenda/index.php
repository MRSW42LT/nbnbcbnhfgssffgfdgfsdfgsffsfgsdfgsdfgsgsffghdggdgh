<?php
include 'classes/contatos.class.php';
include 'inc/head.html';
$contato = new Contatos();

?>


<div class="p-5 text-center bg-image" style="
      background-image: url('https://mdbcdn.b-cdn.net/img/new/slides/041.webp');
      height: 400px;
    ">
    <div class="mask" style="    background: linear-gradient(to right, rgba(137, 247, 254, 0.5), rgba(102, 166, 255, 0.5))

;">
      <div class="d-flex justify-content-center align-items-center h-100">
        <div class="text-primary">
		  <h1 class="mb-3">Agenda</h1>
		  <br>
		  <h1  class="text-warning"><i class="fas fa-chevron-down"></i></h1>
		  <br>
		  <a class="btn btn-warning btn-lg" href="adicionarContato.php" role="button">Adicionar contato</a> 
        </div>
      </div>
    </div>
  </div>
	
<br><br>
	<div class="w-75 mx-auto">
	<h1 class="text-primary">Seus contatos</h1>

	<table border="2" width="100%">
		<tr>
			<th>ID</th>
			<th>NOME</th>
			<th>DDD</th>
			<th>CELULAR</th>
			<th>EMAIL</th>
			<th>CIDADE</th>
			<th>ENDEREÇO</th>
			<th>PROFISSÃO</th>
			<th>FORMAÇÃO</th>
			<th>FACEBOOK</th>
			<th>INSTAGRAM</th>
			<th>DATA NASCIMENTO</th>
			<th>FOTO</th>
			<th>AÇÕES</th>
		</tr>
		<?php
			$lista = $contato->listar();
			foreach($lista as $item):
		?>
		<tr>
			<td><?php echo $item['id']; ?></td>
			<td><?php echo $item['nome']; ?></td>
			<td><?php echo $item['ddd']; ?></td>
			<td><?php echo $item['celular']; ?></td>
			<td><?php echo $item['email']; ?></td>
			<td><?php echo $item['cidade']; ?></td>
			<td><?php echo $item['endereco']; ?></td>
			<td><?php echo $item['profissao']; ?></td>
			<td><?php echo $item['formacao']; ?></td>
			<td><?php echo $item['facebook']; ?></td>
			<td><?php echo $item['instagram']; ?></td>
			<td><?php echo implode("/", array_reverse(explode("-", $item ['data_nasc'])));?></td>
			<td><?php echo $item['url_foto']; ?></td>
			<td> 
				<a href="#">EDITAR</a>
				<a href="excluir_contatos.php?id=<?php echo $item['id'];?>">> EXCLUIR</a>
			</td>
		</tr>
		<?php
			endforeach;
		?>
	</table>
</div>
