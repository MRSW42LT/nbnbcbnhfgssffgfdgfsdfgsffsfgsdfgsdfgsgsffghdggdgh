<?php

include 'classes/contatos.class.php';

$contato = new Contatos();

if(!empty($_POST('id'))) {
    $nome = $_POST['nome'];
	$ddd = $_POST['ddd'];
	$celular = $_POST['celular'];
	$email = $_POST['email'];
	$cidade = $_POST['cidade'];
	$endereco = $_POST['endereco'];
	$profissao = $_POST['profissao'];
	$formacao = $_POST['formacao'];
	$facebook = $_POST['facebook'];
	$instagram = $_POST['instagram'];
	$data_nasc = $_POST['data_nasc'];
	$url_foto = $_POST['url_foto'];
    $id = $_POST('id');


	if(!empty($email)) {
		$contato->editar($nome, $ddd, $celular, $email, $cidade, $endereco, $profissao, $formacao, $facebook, $instagram, $data_nasc, $url_foto, $id);
	}

	header("Location: /agenda4a2022");

}

?>