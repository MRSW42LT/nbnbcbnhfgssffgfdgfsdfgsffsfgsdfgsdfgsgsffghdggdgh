<?php
include 'inc/head.html';

?>
<!-- MDB -->
<script
  type="text/javascript"
  src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/5.0.0/mdb.min.js"
></script>
<div class="p-5 text-center bg-image" style="
      background-image: url('https://mdbcdn.b-cdn.net/img/new/slides/041.webp');
      height: 250px;
    ">
    <div class="mask" style="    background: linear-gradient(to right, rgba(137, 247, 254, 0.5), rgba(102, 166, 255, 0.5))

;">
      <div class="d-flex justify-content-center align-items-center h-100">
        <div class="text-primary"><br><br>
		  <h1 class="mb-3"> Adicionar Contato</h1>
		  <br>
		  <h1 class="text-warning"><i class="fas fa-chevron-down"></i></h1>
		  <br>
        </div>
      </div>
    </div>
  </div>

  <div class="w-50 m-auto mt-5">

  <h3 class="text-primary">Cadastro:</h3><br>

  <form>
  <!-- 2 column grid layout with text inputs for the first and last names -->
  <div class="row mb-4">
    <div class="col">
      <div class="">
	  <i class="fa-solid fa-person"></i><label class="form-label" for="form6Example1">⠀Nome completo</label>

        <input type="text" id="form6Example1" class="form-control" />
      </div>
    </div>
    <div class="col">
      <div class="">
		<i class="fa-solid fa-phone"></i><label class="form-label" for="form6Example2">⠀Celular</label>
		<input type="text" id="form6Example2" class="form-control" />
      </div>
    </div>
  </div>

  <div class="row mb-4">
    <div class="col">
      <div class="">
		<i class="fa-solid fa-envelope"></i><label class="form-label" for="form6Example1">⠀Email</label>
		<input type="text" id="form6Example1" class="form-control" />

      </div>
    </div>
    <div class="col">
      <div class="">
		<i class="fa-solid fa-city"></i><label class="form-label" for="form6Example2">⠀Cidade</label>
		<input type="text" id="form6Example2" class="form-control" />

      </div>
    </div>
  </div>

  <div class="row mb-4">
    <div class="col">
      <div class="">
		<i class="fa-solid fa-house"></i><label class="form-label" for="form6Example1">⠀Endereço</label>
		<input type="text" id="form6Example1" class="form-control" />

      </div>
    </div>
    <div class="col">
      <div class="">
		<i class="fa-solid fa-briefcase"></i><label class="form-label" for="form6Example2">⠀Profissão</label>
		<input type="text" id="form6Example2" class="form-control" />

      </div>
    </div>
  </div>
  <div class="row mb-4">
    <div class="col">
      <div class="">
		<i class="fa-solid fa-building-columns"></i><label class="form-label" for="form6Example1">⠀Formação</label>
		<input type="text" id="form6Example1" class="form-control" />

      </div>
    </div>
    <div class="col">
      <div class="">
		<i class="fa-brands fa-facebook"></i><label class="form-label" for="form6Example2">⠀Facebook</label>
		<input type="text" id="form6Example2" class="form-control" />

      </div>
    </div>
  </div>
  <div class="row mb-4">
    <div class="col">
      <div class="">
		<i class="fa-solid fa-hashtag"></i><label class="form-label" for="form6Example1">⠀Instagram</label>
		<input type="text" id="form6Example1" class="form-control" />

      </div>
    </div>
    <div class="col">
      <div class="">
		<i class="fa-solid fa-baby"></i><label class="form-label" for="form6Example2">⠀Data de nascimento </label>
		<input type="text" id="form6Example2" class="form-control" />

      </div>
    </div>
  </div>
  <div class="row mb-4">
    <div class="col">
		 <i class="fa-solid fa-image"></i><label class="form-label" for="form6Example1">⠀Endereço de foto</label>
		 <input type="text" id="form6Example2" class="form-control" />

      </div>
    </div>

  <!-- Message input -->
  <div class=" mb-4">
	<i class="fa-solid fa-comments"></i><label class="form-label" for="form6Example7">⠀Informação adicional</label>
	<textarea class="form-control" id="form6Example7" rows="4"></textarea>

  </div>

  <!-- Submit button -->
  <button type="submit" class="btn btn-primary btn-block mb-4">Cadastrar contato</button>
</form>


</div>